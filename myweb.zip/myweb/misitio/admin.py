from .models import Cliente
from django.contrib import admin

admin.site.register(Cliente)

