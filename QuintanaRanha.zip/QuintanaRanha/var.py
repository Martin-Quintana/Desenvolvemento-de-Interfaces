'''
Fichero de variables globales
'''
global ui
global motor
global avisosalir
global dlgcalendar
global dlgabrir
global bbdd